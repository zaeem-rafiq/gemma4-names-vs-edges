"""Opaque renaming for Study B (the "opaque identifiers" condition), with a leak scan.

One consistent, seeded bijection per repository over project-defined names, applied to the
issue text (including tracebacks and paths), candidate code and graph context. Rules (pre-registration,
section 4, made concrete here; each is a pre-registration item):

* Renamed: project-defined names collected with `ast` from every Python file of the repository
  snapshot (tests included, vendored folders excluded): module and package path components,
  classes, functions and methods at any depth, module- and class-level assigned names, and
  attributes assigned on self or cls.
* Never renamed: Python keywords, builtins, dunder names, standard-library module names,
  attributes of builtin types, third-party names (every name the repository imports from a module
  outside itself, its alias, and every attribute it reads from such an import), generic folder
  names (src, lib, tests, docs ...), and names shorter than 3 characters or without a letter.
* Pseudo-words are drawn per sub-token with the generator of ngraph.names (the Study A neutral
  names): sub-token consistent, case pattern, underscores and digits kept; common English words,
  protected names, project names and identity names are rejected; short sub-tokens fall back to
  longer pseudo-words when the short shapes run out. There is no token-count matching: Study B truncates on spans of the original text and maps the
  cut onto the renamed text (map_offset).
* Code (candidate code, graph context, fenced and inline code in the issue, traceback lines):
  every renamable name is renamed. Prose: a renamable name is renamed if it is identifier-shaped
  (underscore, inner capital, leading underscore), part of a dotted path, or not a common English
  word; other prose words are left alone.
* Scrubbed: identity names (repository, organisation and top-level package names, plus any extra
  names given, such as maintainers) as whole words in any case become the renamed package name
  (or "<name>" when they are not project names), and so do identity words that are whole
  sub-tokens of other non-protected names (FLASK_APP, RequestsJSONDecodeError); URLs that contain
  an identity name become "<url>"; GitHub handles in prose become "@user". Aliases given to
  project imports (import ... as X) count as project-defined names.
* Leak scan: an independent pass over the renamed text. Hard leaks: a renamable name that is
  identifier-shaped, uncommon or inside a dotted path; an identity name as a whole word or as a
  sub-token of a non-protected name; a URL that contains an identity name. Soft: renamable common words left in prose (expected). Residual
  cues: identity names inside other tokens (for example a third-party package named after the
  project), which are disclosed rather than removed.
"""

from __future__ import annotations

import ast
import builtins
import keyword
import os
import random
import re
import subprocess
import sys
from bisect import bisect_right
from collections import Counter, defaultdict
from dataclasses import dataclass, field

from ngraph.extract import Extractor, module_name_for, src_is_package
from ngraph.names import RESERVED, _pseudo_word, _render, _syllable, shape

RENAME_VERSION = "0.1.0"
MIN_LEN = 3
GENERIC_PATHS = frozenset("src lib tests test testing docs doc examples example scripts tools benchmarks "
                          "bench conftest setup".split())
VENDORED = frozenset("_vendor vendor vendored third_party site-packages node_modules .venv venv build dist "
                     ".git .tox .nox".split())
_BUILTIN_TYPES = (str, bytes, bytearray, int, float, complex, bool, list, tuple, dict, set, frozenset,
                  object, type, BaseException, memoryview, range, slice, property, staticmethod,
                  classmethod, super)

TOKEN_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
DOTTED_RE = re.compile(r"(?<![\w.])[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)+")
URL_RE = re.compile(r"https?://[^\s<>()\[\]\"'`]+")
HANDLE_RE = re.compile(r"(?<![\w@./])@[A-Za-z0-9](?:[A-Za-z0-9-]{0,38})(?![\w-])")
FENCE_RE = re.compile(r"^[ \t]*(`{3,}|~{3,})[^\n]*\n.*?(?:^[ \t]*\1[ \t]*$|\Z)", re.M | re.S)
INLINE_RE = re.compile(r"(?<!`)`([^`\n]+)`(?!`)")
FRAME_LINE_RE = re.compile(r'^[ \t]*File "[^"\n]+", line \d+(?:, in \S+)?[^\n]*$', re.M)
TB_LINE_RE = re.compile(r"^[ \t]*(?:Traceback \(most recent call last\):|[A-Za-z_][\w.]*(?:Error|Exception|Warning|Exit|Interrupt)\b:?)[^\n]*$", re.M)


def is_identifier_shaped(w: str) -> bool:
    core = w.strip("_")
    return bool(core) and (w.startswith("_") or "_" in core or re.search(r"[a-z0-9][A-Z]|[A-Z]{2}[a-z]", w) is not None)


def builtin_protected() -> set:
    s = set(keyword.kwlist) | set(getattr(keyword, "softkwlist", [])) | set(dir(builtins))
    for t in _BUILTIN_TYPES:
        s |= set(dir(t))
    s |= set(getattr(sys, "stdlib_module_names", ()))
    return s


def _case_like(src: str, new: str) -> str:
    if src.isupper() and len(src) > 1:
        return new.upper()
    if src[:1].isupper():
        return new[:1].upper() + new[1:]
    return new


def repo_python_files(root: str) -> list[str]:
    if os.path.isdir(os.path.join(root, ".git")):
        out = subprocess.run(["git", "-C", root, "ls-files", "*.py"], capture_output=True, text=True,
                             check=True).stdout.splitlines()
    else:
        out = [os.path.relpath(os.path.join(d, f), root) for d, _, fs in os.walk(root) for f in fs if f.endswith(".py")]
    return sorted(f for f in out if f.strip() and not set(f.replace(os.sep, "/").split("/")[:-1]) & VENDORED)


# ----------------------------------------------------------------------------- names
@dataclass
class ProjectNames:
    defined: dict = field(default_factory=dict)        # name -> sorted kinds
    third_party: set = field(default_factory=set)
    packages: list = field(default_factory=list)       # top-level project packages
    identity: list = field(default_factory=list)       # lower-case identity words
    extra_identity: list = field(default_factory=list)  # free-form strings (e.g. maintainer names)
    parse_errors: list = field(default_factory=list)

    @property
    def protected(self) -> set:
        return builtin_protected() | self.third_party

    def renamable(self) -> list[str]:
        prot = self.protected
        out = []
        for n in self.defined:
            if (len(n) < MIN_LEN or not re.search(r"[A-Za-z]", n) or n in prot or n in GENERIC_PATHS
                    or (n.startswith("__") and n.endswith("__"))):
                continue
            out.append(n)
        return sorted(out)


def collect_names(root: str, files: list[str] | None = None, repo: str | None = None,
                  org: str | None = None, extra_identity=()) -> ProjectNames:
    files = repo_python_files(root) if files is None else files
    strip = not src_is_package(root, files)
    mods = {}
    for rel in files:
        mod, _ = module_name_for(rel, strip)
        if mod:
            mods[rel] = mod
    project_tops = {m.split(".")[0] for m in mods.values()}
    defined = defaultdict(set)
    third = set()
    errors = []

    def add(name, kind):
        if name:
            defined[name].add(kind)

    for rel, mod in mods.items():
        for comp in mod.split("."):
            add(comp, "module")
        try:
            with open(os.path.join(root, rel), "rb") as fh:
                tree = ast.parse(fh.read(), filename=rel)
        except (SyntaxError, ValueError, OSError) as exc:
            errors.append(f"{rel}: {type(exc).__name__}")
            continue
        foreign_roots = set()
        for n in ast.walk(tree):
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                add(n.name, "function")
            elif isinstance(n, ast.ClassDef):
                add(n.name, "class")
                for st in Extractor._toplevel_stmts(n.body):
                    for t in _assign_targets(st):
                        add(t, "class_attribute")
            elif isinstance(n, ast.Attribute) and isinstance(n.ctx, ast.Store) and \
                    isinstance(n.value, ast.Name) and n.value.id in ("self", "cls"):
                add(n.attr, "attribute")
            elif isinstance(n, ast.Import):
                for a in n.names:
                    if a.name.split(".")[0] in project_tops:
                        if a.asname:
                            add(a.asname, "alias")
                    else:
                        third.update(a.name.split("."))
                        bound = a.asname or a.name.split(".")[0]
                        third.add(bound)
                        foreign_roots.add(bound)
            elif isinstance(n, ast.ImportFrom):
                if n.level > 0 or (n.module and n.module.split(".")[0] in project_tops):
                    for a in n.names:
                        if a.asname:
                            add(a.asname, "alias")
                elif n.module:
                    third.update(n.module.split("."))
                    for a in n.names:
                        if a.name != "*":
                            third.add(a.name)
                            third.add(a.asname or a.name)
                            foreign_roots.add(a.asname or a.name)
        for st in Extractor._toplevel_stmts(tree.body):
            for t in _assign_targets(st):
                add(t, "module_variable")
        # attribute chains read from third-party or standard-library imports
        for n in ast.walk(tree):
            if isinstance(n, ast.Attribute):
                chain, cur = [], n
                while isinstance(cur, ast.Attribute):
                    chain.append(cur.attr)
                    cur = cur.value
                if isinstance(cur, ast.Name) and cur.id in foreign_roots:
                    third.update(chain)
    tops = sorted(t for t in project_tops if t not in GENERIC_PATHS)
    ident = {t.lower() for t in tops}
    for x in (repo, org):
        if x:
            ident.add(x.lower())
    return ProjectNames({k: sorted(v) for k, v in sorted(defined.items())}, third, tops, sorted(ident),
                        list(extra_identity), errors)


def _assign_targets(st) -> list[str]:
    out = []
    if isinstance(st, ast.Assign):
        targets = st.targets
    elif isinstance(st, (ast.AnnAssign, ast.AugAssign)):
        targets = [st.target]
    else:
        return out
    for t in targets:
        for n in ast.walk(t):
            if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Store):
                out.append(n.id)
    return out


# ----------------------------------------------------------------------------- pseudo-words
class OpaqueNamer:
    """Sub-token-consistent pseudo-word renaming that scales to whole repositories (O(names))."""

    def __init__(self, seed: int, reject, forbidden=(), taken_names=()):
        self.rng = random.Random(seed)
        self.reject = reject
        self.forbidden = sorted({f for f in forbidden if len(f) >= 3})
        self.taken_names = set(taken_names)
        self.sub_map: dict[str, str] = {}
        self.map: dict[str, str] = {}
        self.used: set[str] = set()
        self.fallback: set[str] = set()
        self._by_sub = defaultdict(set)

    def _free(self, w: str, sub: str) -> bool:
        return (w != sub and w not in self.used and w not in RESERVED and not any(f in w for f in self.forbidden)
                and not (len(w) > 1 and self.reject(w)))

    def _draw(self, sub: str) -> str:
        for widen in range(3 if len(sub) <= 2 else 1):
            for _ in range(400):
                w = _pseudo_word(self.rng, sub, None, widen)
                if self._free(w, sub):
                    return w
        for _ in range(20000):  # short shapes used up: a longer pseudo-word
            w = "".join(_syllable(self.rng) for _ in range(self.rng.randint(2, 3)))
            if self._free(w, sub):
                self.fallback.add(sub)
                return w
        raise RuntimeError(f"could not draw a pseudo-word for sub-token {sub!r}")

    @staticmethod
    def _subs(comp: str) -> list[str]:
        _, parts, _, _ = shape(comp)
        return [t.lower() for humps in parts for k, t in humps if k != "digit"]

    def compose(self, comp: str) -> str:
        prefix, parts, suffix, seps = shape(comp)
        pieces = ["".join(t if k == "digit" else _render(k, self.sub_map[t.lower()]) for k, t in humps)
                  for humps in parts]
        return prefix + pieces[0] + "".join(sep + p for sep, p in zip(seps, pieces[1:])) + suffix

    def _valid(self, comp: str, new: str, owner: dict) -> bool:
        low = new.lower()
        if new == comp or low in RESERVED or new in self.taken_names or any(f in low for f in self.forbidden):
            return False
        if any(self.reject(p.lower()) for p in re.split(r"[_-]", new) if len(p) > 1 and p.isalpha()):
            return False
        return owner.get(new, comp) == comp

    def fit(self, comps) -> None:
        comps = [c for c in dict.fromkeys(comps) if c not in self.map]
        for c in comps:
            for t in self._subs(c):
                self._by_sub[t].add(c)
                if t not in self.sub_map:
                    w = self._draw(t)
                    self.sub_map[t] = w
                    self.used.add(w)
        owner = {v: k for k, v in self.map.items()}
        todo = list(comps)
        for _ in range(100):
            bad = []
            for c in todo:
                new = self.compose(c)
                if self._valid(c, new, owner):
                    owner[new] = c
                    self.map[c] = new
                else:
                    bad.append(c)
            if not bad:
                return
            redo = set()
            for c in bad:
                subs = [t for t in self._subs(c)]
                if not subs:
                    raise RuntimeError(f"name {c!r} has no letters to rename")
                t = subs[self.rng.randrange(len(subs))]
                self.used.discard(self.sub_map[t])
                self.sub_map[t] = self._draw(t)
                self.used.add(self.sub_map[t])
                redo |= self._by_sub[t]
            for c in redo:  # names that share a redrawn sub-token are composed again
                if c in self.map:
                    owner.pop(self.map.pop(c), None)
            todo = sorted(redo | set(bad))
        raise RuntimeError("could not find a valid opaque renaming")


# ----------------------------------------------------------------------------- renamer
@dataclass
class Rendered:
    text: str
    spans: list            # (orig_start, orig_end, new_start, new_end) for every replacement
    n_tokens: int          # identifier tokens in the original text
    n_renamed: int         # identifier tokens renamed

    @property
    def share_changed(self) -> float:
        return self.n_renamed / self.n_tokens if self.n_tokens else 0.0


def map_offset(spans, k: int) -> int:
    """Original offset -> renamed offset. Inside a replaced span, the cut moves to its end."""
    starts = [s[0] for s in spans]
    i = bisect_right(starts, k) - 1
    if i >= 0:
        os_, oe, ns, ne = spans[i]
        if os_ < k < oe:
            return ne
        if k >= oe:
            return ne + (k - oe)
    return k


class OpaqueRenamer:
    def __init__(self, names: ProjectNames, seed: int = 1, common_word=None):
        if common_word is None:
            from ngraph.items import common_word_filter
            common_word = common_word_filter()
        self.names = names
        self.seed = seed
        self.common = common_word
        self.protected = names.protected
        renamable = names.renamable()
        self.renamable = set(renamable)
        prot_low = {p.lower() for p in self.protected}
        ren_low = {r.lower() for r in renamable}

        def reject(w):
            lw = w.lower()
            return common_word(lw) or lw in prot_low or lw in ren_low

        self.namer = OpaqueNamer(seed, reject, forbidden=names.identity,
                                 taken_names=set(self.protected) | set(renamable))
        for i in range(0, len(renamable), 500):
            self.namer.fit(renamable[i:i + 500])
        self.map = {n: self.namer.map[n] for n in renamable}
        ident = [i for i in names.identity if i not in prot_low]
        self.namer.fit([i for i in ident if i not in self.map])  # identity words that are not module names
        self.identity_map = {i: self.namer.map[i] for i in ident}
        self.identity_re = _words_re(ident)
        self.url_identity_re = _words_re(names.identity, substring=True)
        self.extra_re = re.compile("|".join(re.escape(x) for x in names.extra_identity), re.I) \
            if names.extra_identity else None
        inv = {}
        for k, v in self.map.items():
            if v in inv:
                raise RuntimeError(f"not a bijection: {k} and {inv[v]} -> {v}")
            inv[v] = k
        self.inverse = inv

    # ------------------------------------------------------------------ segmentation
    @staticmethod
    def code_spans(text: str) -> list[tuple[int, int]]:
        spans = [(m.start(), m.end()) for m in FENCE_RE.finditer(text)]
        spans += [(m.start(1), m.end(1)) for m in INLINE_RE.finditer(text)]
        for m in FRAME_LINE_RE.finditer(text):
            spans.append((m.start(), m.end()))
            nxt = text.find("\n", m.end() + 1)
            line = text[m.end() + 1: nxt if nxt != -1 else len(text)]
            if m.end() < len(text) and line.startswith((" ", "\t")):
                spans.append((m.end() + 1, m.end() + 1 + len(line)))
        spans += [(m.start(), m.end()) for m in TB_LINE_RE.finditer(text)]
        return _merge(spans)

    # ------------------------------------------------------------------ renaming
    def _identity_new(self, word: str) -> str:
        new = self.identity_map.get(word.lower())
        return _case_like(word, new) if new else "<name>"

    def _render(self, text: str, all_code: bool) -> Rendered:
        code = [(0, len(text))] if all_code else self.code_spans(text)
        repl = []
        blocked = []
        for m in URL_RE.finditer(text):
            u = m.group(0)
            if (self.url_identity_re and self.url_identity_re.search(u)) or (self.extra_re and self.extra_re.search(u)):
                repl.append((m.start(), m.end(), "<url>"))
            blocked.append((m.start(), m.end()))
        if self.extra_re:
            for m in self.extra_re.finditer(text):
                if not _inside(_merge(blocked), m.start()):
                    repl.append((m.start(), m.end(), "<name>"))
                    blocked.append((m.start(), m.end()))
        if not all_code:
            for m in HANDLE_RE.finditer(text):
                if not _inside(_merge(blocked), m.start()) and not _inside(code, m.start()):
                    repl.append((m.start(), m.end(), "@user"))
                    blocked.append((m.start(), m.end()))
        blocked = _merge(blocked)
        dotted = _merge([(m.start(), m.end()) for m in DOTTED_RE.finditer(text)])
        n_tok = n_ren = 0
        for m in TOKEN_RE.finditer(text):
            if _inside(blocked, m.start()):
                continue
            tok = m.group(0)
            n_tok += 1
            new = self._rename_token(tok, _inside(code, m.start()), _inside(dotted, m.start()))
            if new != tok:
                repl.append((m.start(), m.end(), new))
                n_ren += 1
        repl.sort()
        out, spans, pos, shift = [], [], 0, 0
        for s, e, new in repl:
            if s < pos:
                continue  # overlaps an earlier replacement (URL or name already scrubbed)
            out.append(text[pos:s])
            ns = s + shift
            out.append(new)
            spans.append((s, e, ns, ns + len(new)))
            shift += len(new) - (e - s)
            pos = e
        out.append(text[pos:])
        return Rendered("".join(out), spans, n_tok, n_ren)

    def _rename_token(self, tok: str, in_code: bool, in_dotted: bool) -> str:
        if tok in self.map:
            if in_code or in_dotted or is_identifier_shaped(tok) or not self.common(tok.lower()):
                return self.map[tok]
            # a common English word in prose; identity words are still scrubbed below
        if self.identity_re and tok.lower() in self.identity_map and self.identity_re.fullmatch(tok):
            return self._identity_new(tok)
        if tok not in self.protected and self.identity_map:
            return self._scrub_subtokens(tok)
        return tok

    def _identity_humps(self, tok: str) -> bool:
        _, parts, _, _ = shape(tok)
        return any(k != "digit" and t.lower() in self.identity_map for humps in parts for k, t in humps)

    def _scrub_subtokens(self, tok: str) -> str:
        """FLASK_APP -> ZORKA_APP: identity words that are whole sub-tokens of another name."""
        if not self._identity_humps(tok):
            return tok
        prefix, parts, suffix, seps = shape(tok)
        pieces = ["".join(_render(k, self.identity_map[t.lower()]) if k != "digit" and t.lower() in self.identity_map
                          else t for k, t in humps) for humps in parts]
        return prefix + pieces[0] + "".join(sep + p for sep, p in zip(seps, pieces[1:])) + suffix

    def rename_code(self, text: str) -> Rendered:
        return self._render(text, all_code=True)

    def rename_issue(self, text: str) -> Rendered:
        return self._render(text, all_code=False)

    # ------------------------------------------------------------------ leak scan
    def leak_scan(self, renamed: str) -> dict:
        hard, soft, residual = Counter(), Counter(), Counter()
        dotted = _merge([(m.start(), m.end()) for m in DOTTED_RE.finditer(renamed)])
        urls = [(m.start(), m.end()) for m in URL_RE.finditer(renamed)]
        for m in URL_RE.finditer(renamed):
            if self.url_identity_re and self.url_identity_re.search(m.group(0)):
                hard["<url with identity>"] += 1
        for m in TOKEN_RE.finditer(renamed):
            if _inside(urls, m.start()):
                continue
            t = m.group(0)
            low = t.lower()
            if low in self.identity_map and t not in self.inverse:
                hard[t] += 1
            elif t in self.renamable:
                if _inside(dotted, m.start()) or is_identifier_shaped(t) or not self.common(low):
                    hard[t] += 1
                else:
                    soft[t] += 1
            elif t not in self.inverse and t not in self.protected and self._identity_humps(t):
                hard[t] += 1
            elif any(i in low for i in self.identity_map if len(i) >= 4):
                residual[t] += 1  # identity word inside another token (e.g. a third-party package)
        if self.extra_re:
            for m in self.extra_re.finditer(renamed):
                hard[m.group(0)] += 1
        return {"ok": not hard, "hard": dict(hard), "soft": dict(soft), "residual_identity": dict(residual)}

    def export(self) -> dict:
        return {"rename_version": RENAME_VERSION, "seed": self.seed, "map": dict(sorted(self.map.items())),
                "identity_map": self.identity_map, "sub_map": dict(sorted(self.namer.sub_map.items())),
                "fallback_subtokens": sorted(self.namer.fallback),
                "n_protected_defined": sum(1 for n in self.names.defined if n in self.protected),
                "packages": self.names.packages}


def _words_re(words, substring: bool = False):
    words = sorted({w for w in words if w}, key=len, reverse=True)
    if not words:
        return None
    alt = "|".join(map(re.escape, words))
    return re.compile(alt if substring else r"(?<![A-Za-z0-9])(" + alt + r")(?![A-Za-z0-9])", re.I)


def _merge(spans):
    out = []
    for s, e in sorted(spans):
        if out and s <= out[-1][1]:
            out[-1] = (out[-1][0], max(out[-1][1], e))
        else:
            out.append((s, e))
    return out


def _inside(spans, k: int) -> bool:
    lo, hi = 0, len(spans)
    while lo < hi:
        mid = (lo + hi) // 2
        if spans[mid][1] <= k:
            lo = mid + 1
        else:
            hi = mid
    return lo < len(spans) and spans[lo][0] <= k < spans[lo][1]
